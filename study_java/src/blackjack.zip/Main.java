package 블랙잭;


public class Main {

	public static void main(String[] args) {

		BlackJack game = new BlackJack();

		game.run();

	}

}
